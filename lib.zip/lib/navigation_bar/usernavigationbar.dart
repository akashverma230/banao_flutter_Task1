import 'package:banao/ui/mainscreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:persistent_bottom_nav_bar/persistent_tab_view.dart';

class UserBar extends StatelessWidget {
  const UserBar({super.key});

  @override
  Widget build(BuildContext context) {
    return PersistentTabView(context, screens: _screens(),
    items: _navbar(),
navBarStyle: NavBarStyle.style3,
    );
  }
}
List<PersistentBottomNavBarItem> _navbar() {

  return [PersistentBottomNavBarItem(
    
    icon: Icon(Icons.home),
  title: 'Home',
  //activeColorPrimary: Color.fromRGBO(161, 0, 0, 0.0),
                //inactiveColorPrimary:Colors.grey,
                
),
  PersistentBottomNavBarItem(icon: Icon(Icons.import_contacts_rounded),
  title: 'Learn',
  //activeColorPrimary: Color.fromRGBO(161, 0, 0, 0.0),
                //inactiveColorPrimary: Colors.grey,
),

PersistentBottomNavBarItem(icon: Icon(Icons.window_outlined),
title: 'Hub',
//activeColorPrimary: Color.fromRGBO(161, 0, 0, 0.0),
               // inactiveColorPrimary: Colors.grey,

),
PersistentBottomNavBarItem(icon: Icon(Icons.chat_bubble_outline),
title: 'Chat',
//activeColorPrimary: Color.fromRGBO(161, 0, 0, 0.0),
                //inactiveColorPrimary: Colors.grey,

),
PersistentBottomNavBarItem(icon: CircleAvatar(
  radius: 10,
  backgroundImage: NetworkImage('https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg'),),
title: 'Profile',
//activeColorPrimary: Color.fromRGBO(161, 0, 0, 0.0),
                //inactiveColorPrimary: Colors.grey,)




  )];
}

List<Widget> _screens() {
  return [MainScreen(), Container(color: Colors.red,), Container(color: Colors.yellow,), Container(color: Colors.green,), Container(color: Colors.blue,)];
}
