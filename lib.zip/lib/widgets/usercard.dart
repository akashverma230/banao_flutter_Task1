import 'package:flutter/material.dart';

Widget Usercards(String subtitle, String title, String lessons, String img,BuildContext ctx) {
  return Container(
    height: MediaQuery.of(ctx).size.height*0.40,
    width: MediaQuery.of(ctx).size.width*0.70,
    child: Card(
      elevation: 10,
      shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(15.0),
  ),
      child: Column(
        children: [
          Image.network(img),
          Container(
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: Text(
                    subtitle,
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
                SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: Text(
                    title,
                    style: TextStyle(color: Colors.black, fontSize: 20,fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: Row(
                    children: [
                      Text(
                        lessons,
                        style: TextStyle(color: Colors.grey),
                      ),
                      SizedBox(width: MediaQuery.of(ctx).size.width*0.30,),
                      Container(
                        height: 25,
                        width: 60,
                        decoration: BoxDecoration(border: Border.all(color: Colors.blue,width: 2),borderRadius: BorderRadius.circular(15)),
                        child: Center(child: Text('Book',style: TextStyle(color: Colors.blue),)),)
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    ),
  );
}
