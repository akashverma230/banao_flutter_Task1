import 'package:flutter/material.dart';

Widget UserContainer(IconData icon, String txt,BuildContext ctx) {
  return Container(
    width: MediaQuery.of(ctx).size.width*0.45,
    padding: EdgeInsets.all(8),
    decoration: BoxDecoration(border: Border.all(color: Colors.blue,width: 2),borderRadius: BorderRadius.circular(5)),
    child: Row(
      children: [Icon(icon,color: Colors.blue,),SizedBox(width: 20,), Text(txt,style: TextStyle(fontWeight: FontWeight.bold,color: Colors.blue),)],
    ),
  );
}
