import 'package:banao/widgets/usercard.dart';
import 'package:banao/widgets/usercard2.dart';
import 'package:banao/widgets/usercard3.dart';
import 'package:banao/widgets/usercontainer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:google_fonts/google_fonts.dart';

class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
          leading: IconButton(
              onPressed: () {}, icon: Icon(Icons.short_text_rounded,color: Colors.grey,size: 45,)),
          actions: [
            IconButton(onPressed: (){}, icon: Icon(Icons.question_answer,color: Colors.grey,size: 30,)),
            IconButton(onPressed: () {}, icon: Icon(Icons.notifications_none,color: Colors.grey,size: 35))
          ]),
          body: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text('Hello,Priya!',style: TextStyle(color: Colors.black,fontSize: 40),),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text('What do you wanna learn today?',style: TextStyle(color: Colors.grey,fontSize: 20),),
                ),
                SizedBox(height: MediaQuery.of(context).size.height*0.05,),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      UserContainer(Icons.book, 'Programs',context),
                      SizedBox(width: MediaQuery.of(context).size.width*0.05,),
                      UserContainer(Icons.help, 'Get help', context)
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      UserContainer(Icons.menu_book_rounded, 'Learn',context),
                      SizedBox(width: MediaQuery.of(context).size.width*0.05,),
                      UserContainer(Icons.view_cozy, 'DD Tracker', context)
                    ],
                  ),
                ),
                SizedBox(height: MediaQuery.of(context).size.height*0.03,),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(children: [
                    Text('Programs For You',style: GoogleFonts.ptSerif(fontSize: 20)),
                    SizedBox(width: MediaQuery.of(context).size.width*0.30,),
                    Text('View All',style: TextStyle(color: Colors.grey),),
                    Icon(Icons.arrow_forward)
                  ],),
                ),
                SizedBox(height: MediaQuery.of(context).size.height*0.03,),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      UserCard3('Lifestyle', 'A complete guide for your new born baby', '16 lessons', 'https://i0.wp.com/journomed.com/wp-content/uploads/2022/03/shutterstock_1565608939-scaled.jpg', context),
                      UserCard3('Lifestyle', 'A complete guide for your new born baby', '12 lessons', 'https://i0.wp.com/journomed.com/wp-content/uploads/2022/03/shutterstock_1565608939-scaled.jpg', context)
                    ],
                  ),
                ),
                SizedBox(height: MediaQuery.of(context).size.height*0.03,),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(children: [
                    Text('Events and Experiences',style: GoogleFonts.ptSerif(fontSize: 20)),
                    SizedBox(width: MediaQuery.of(context).size.width*0.15,),
                    Text('View All',style: TextStyle(color: Colors.grey),),
                    Icon(Icons.arrow_forward),
                    
                  ],),
                ),
                SizedBox(height: MediaQuery.of(context).size.height*0.03,),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      Usercards('BABYCARE', 'Understanding of human behaviour', '16 lessons', 'https://img.freepik.com/free-photo/young-woman-doing-natarajasana-exercise_1163-5070.jpg',context),
                      Usercards('BABYCARE', 'Understanding of human behaviour', '16 lessons', 'https://img.freepik.com/free-photo/young-woman-doing-natarajasana-exercise_1163-5070.jpg',context),
                    ],
                  ),
                ),
                SizedBox(height: MediaQuery.of(context).size.height*0.03,),
                              Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(children: [
                    Text('Lessons For You',style: GoogleFonts.ptSerif(fontSize: 20)),
                    SizedBox(width: MediaQuery.of(context).size.width*0.35,),
                    Text('View All',style: TextStyle(color: Colors.grey),),
                    Icon(Icons.arrow_forward),
                    
                  ],),
                ),
                
                SizedBox(height: MediaQuery.of(context).size.height*0.03,),
                SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          UserCard2('BABYCARE', 'Understanding of human behaviour', '3 min', 'https://img.freepik.com/free-photo/young-woman-doing-natarajasana-exercise_1163-5070.jpg', context),
                          UserCard2('BABYCARE', 'Understanding of human behaviour', '1 min', 'https://img.freepik.com/free-photo/young-woman-doing-natarajasana-exercise_1163-5070.jpg', context)
                        ],
                      ),
                    )
              ],
            ),
          ),
    );
  }
}
